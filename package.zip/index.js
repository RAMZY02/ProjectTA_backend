const express = require('express');
const app = express();
const cors = require('cors');
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

// 🟢 Buat folder session jika belum ada
const sessionDir = './sessions';
if (!fs.existsSync(sessionDir)) {
  fs.mkdirSync(sessionDir, { recursive: true });
}

// 🟢 Status global
let isClientReady = false;
let isAuthenticated = false;
let clientState = 'idle';
let clientInitialized = false;

// 🟢 Custom Auth Strategy aman
class SafeLocalAuth extends LocalAuth {
  async logout() {
    try {
      await super.logout();
      console.log('✅ Logout successful');
    } catch (error) {
      if (error.message.includes('EBUSY')) {
        console.warn('⚠️ EBUSY during logout, skipping cleanup');
        return;
      }
      throw error;
    }
  }
}

let client;

// 🟢 Fungsi untuk kill Chrome
async function killChromeProcesses() {
  return new Promise((resolve) => {
    const cmd =
      process.platform === 'win32'
        ? 'taskkill /f /im chrome.exe /im chromedriver.exe /im chromium.exe'
        : 'pkill -f "chrome|chromium|chromedriver"';
    exec(cmd, (error) => {
      if (!error) console.log('✅ Chrome processes killed');
      resolve();
    });
  });
}

// 🟢 Fungsi cleanup file terkunci
async function cleanupLockedFiles() {
  try {
    const sessionPath = path.join(sessionDir, 'session-my-client');
    if (fs.existsSync(sessionPath)) {
      console.log('🧹 Cleaning up session files...');
      const files = fs.readdirSync(sessionPath);
      for (const file of files) {
        if (file.includes('LOCK')) {
          try {
            fs.renameSync(
              path.join(sessionPath, file),
              path.join(sessionPath, file + '.old')
            );
          } catch (e) {
            console.warn('⚠️ Could not rename:', file);
          }
        }
      }
    }
  } catch (err) {
    console.warn('Cleanup warning:', err.message);
  }
}

// 🟢 Fungsi inisialisasi WhatsApp
async function initializeWhatsAppClient() {
  if (clientInitialized) {
    console.log('⚠️ Client already initialized.');
    return;
  }

  console.log('🚀 Initializing WhatsApp client...');
  clientState = 'initializing';
  clientInitialized = true;

  await killChromeProcesses();
  await cleanupLockedFiles();

  client = new Client({
    puppeteer: {
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--no-first-run',
        '--disable-background-networking',
        '--disable-sync',
        '--disable-extensions',
        '--disable-default-apps',
        '--disable-gpu',
        '--single-process'
      ],
      ignoreHTTPSErrors: true,
    },
    authStrategy: new SafeLocalAuth({
      dataPath: path.resolve(sessionDir),
      clientId: 'my-client',
    }),
    webVersionCache: {
      type: 'remote',
      remotePath:
        'https://raw.githubusercontent.com/wppconnect-team/wa-version/main/html/2.2412.54.html',
    },
  });

  // Event handlers
  client.on('qr', (qr) => {
    console.log('📱 Scan this QR to connect WhatsApp:');
    qrcode.generate(qr, { small: true });
    isAuthenticated = false;
    isClientReady = false;
    clientState = 'waiting_qr';
  });

  client.on('authenticated', () => {
    console.log('✅ AUTHENTICATED');
    isAuthenticated = true;
    clientState = 'authenticated';
  });

  client.on('ready', () => {
    console.log('✅ READY - WhatsApp connected!');
    isClientReady = true;
    clientState = 'ready';
  });

  client.on('disconnected', async (reason) => {
    console.log('❌ DISCONNECTED:', reason);
    isAuthenticated = false;
    isClientReady = false;
    clientState = 'disconnected';
    // ❌ Tidak auto reconnect
  });

  try {
    await client.initialize();
  } catch (err) {
    console.error('Initialization error:', err);
    clientState = 'error';
    clientInitialized = false;
  }
}

// 🟢 Fungsi destroy client manual
async function safeDestroyClient() {
  if (!client) {
    console.log('ℹ️ No client to destroy');
    return;
  }
  console.log('🛑 Destroying WhatsApp client...');
  try {
    await client.destroy();
    await killChromeProcesses();
    await cleanupLockedFiles();
    client = null;
    clientInitialized = false;
    isAuthenticated = false;
    isClientReady = false;
    clientState = 'destroyed';
    console.log('✅ Client destroyed');
  } catch (err) {
    console.error('Destroy error:', err.message);
  }
}

// Import routes
const userRoutes = require('./src/routes/userRoutes');
const commentRoutes = require('./src/routes/commentRoutes');
const hadiahRoutes = require('./src/routes/hadiahRoutes');
const jawabanSiswaRoutes = require('./src/routes/jawabanSiswaRoutes');
const kuponRoutes = require('./src/routes/kuponRoutes');
const notifikasiRoutes = require('./src/routes/notifikasiRoutes');
const soalRoutes = require('./src/routes/soalRoutes');
const ujianRoutes = require('./src/routes/ujianRoutes');
const videoEdukasiRoutes = require('./src/routes/videoEdukasiRoutes');
const historyVideoRoutes = require('./src/routes/historyVideoRoutes');
const historyUjianRoutes = require('./src/routes/historyUjianRoutes');
const historyTugasRoutes = require('./src/routes/historyTugasRoutes');
const cloudFlareR2StorageRoutes = require('./src/routes/cloudFlareR2StorageRoutes');
const tugasRoutes = require('./src/routes/tugasRoutes');
const pengumpulanTugasRoutes = require('./src/routes/pengumpulanTugasRoutes');
const penilaianTugasRoutes = require('./src/routes/penilaianTugasRoutes');
const nilaiAkhirSiswaRoutes = require('./src/routes/nilaiAkhirSiswaRoutes');
const kelasMengajarRoutes = require('./src/routes/kelasMengajarRoutes');
const mataPelajaranRoutes = require('./src/routes/mataPelajaranRoutes');
const tahunPelajaranRoutes = require('./src/routes/tahunPelajaranRoutes');
const { authenticate } = require('./src/middleware/auth');

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  cors({
    origin: "*",
  })
);

// Routes
app.use('/api/users', userRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/hadiah', hadiahRoutes);
app.use('/api/jawaban-siswa', jawabanSiswaRoutes);
app.use('/api/kupon', kuponRoutes);
app.use('/api/notifikasi', notifikasiRoutes);
app.use('/api/soal', soalRoutes);
app.use('/api/ujian', ujianRoutes);
app.use('/api/video-edukasi', videoEdukasiRoutes);
app.use('/api/history-video', historyVideoRoutes);
app.use('/api/history-ujian', historyUjianRoutes);
app.use('/api/history-tugas', historyTugasRoutes);
app.use('/api/tugas', tugasRoutes);
app.use('/api/pengumpulan-tugas', pengumpulanTugasRoutes);
app.use('/api/penilaian-tugas', penilaianTugasRoutes);
app.use('/api/nilai-akhir-siswa', nilaiAkhirSiswaRoutes);
app.use('/api/kelas-mengajar', kelasMengajarRoutes);
app.use('/api/mata-pelajaran', mataPelajaranRoutes);
app.use('/api/tahun-pelajaran', tahunPelajaranRoutes);
app.use('/api/cloudflare', cloudFlareR2StorageRoutes);

app.get('/api', (req, res) => {
  res.status(200).json({ 
    message: 'API is running',
    timestamp: new Date().toISOString(),
    whatsapp_status: clientState
  });
});

// Cek status
app.get('/api/WA/status', (req, res) => {
  res.json({
    isAuthenticated,
    isClientReady,
    clientState,
    timestamp: new Date().toISOString(),
  });
});

// Inisialisasi manual
app.post('/api/WA/init', async (req, res) => {
  if (clientInitialized) {
    return res.json({ message: 'Client already initialized', clientState });
  }
  initializeWhatsAppClient();
  res.json({ message: 'Client initializing...' });
});

// Restart manual
app.post('/api/WA/restart', async (req, res) => {
  await safeDestroyClient();
  await initializeWhatsAppClient();
  res.json({ message: 'Client restarted' });
});

// Kill Chrome manual
app.post('/api/WA/kill-chrome', async (req, res) => {
  await killChromeProcesses();
  res.json({ message: 'Chrome processes killed' });
});

// Send message (tidak berubah)
app.post('/api/WA', async (req, res) => {
  try {
    const { tujuan, pesan } = req.body;
    if (!isClientReady) {
      return res.status(503).json({ message: 'Client not ready' });
    }

    let nomor = tujuan.replace(/^0/, '62').replace(/[+\s-]/g, '');
    if (!nomor.endsWith('@c.us')) nomor += '@c.us';

    const result = await client.sendMessage(nomor, pesan);
    res.json({
      success: true,
      data: {
        to: nomor,
        messageId: result.id._serialized,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () =>
  console.log(`🚀 Server running on port ${PORT}`)
);